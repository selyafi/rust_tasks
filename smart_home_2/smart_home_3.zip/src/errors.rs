pub mod smart_home_errors;
