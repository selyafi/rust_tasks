pub mod bed_room;
pub mod device;
pub mod kitchen;
pub mod living_room;
pub mod report;
pub mod room;
pub mod socket;
pub mod thermometer;
