mod room_tests;
mod smart_home_tests;
mod socket_tests;
mod thermometer_tests;
