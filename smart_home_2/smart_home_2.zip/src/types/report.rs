pub struct Report {
    pub room: String,
    pub socket: String,
    pub device: String,
    pub value: String,
}
